import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';

void main() {
  runApp(const KasirTabunganApp());
}

class KasirTabunganApp extends StatelessWidget {
  const KasirTabunganApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Kasir & Tabungan Pro',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF006D5B),
          brightness: Brightness.light,
        ),
        useMaterial3: true,
      ),
      home: const MainNavigation(),
    );
  }
}

// --- FORMAT RUPIAH ---
String formatRupiah(double nominal) {
  final format = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);
  return format.format(nominal);
}

// --- MODEL DATA ---
class Transaksi {
  final String id;
  final String judul;
  final double nominal;
  final double modal;
  final bool isPemasukan;
  final DateTime tanggal;

  Transaksi({
    required this.id,
    required this.judul,
    required this.nominal,
    this.modal = 0,
    required this.isPemasukan,
    required this.tanggal,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'judul': judul,
        'nominal': nominal,
        'modal': modal,
        'isPemasukan': isPemasukan,
        'tanggal': tanggal.toIso8601String(),
      };

  factory Transaksi.fromJson(Map<String, dynamic> json) => Transaksi(
        id: json['id'],
        judul: json['judul'],
        nominal: (json['nominal'] as num).toDouble(),
        modal: (json['modal'] as num?)?.toDouble() ?? 0,
        isPemasukan: json['isPemasukan'],
        tanggal: DateTime.parse(json['tanggal']),
      );
}

class Produk {
  String id;
  String nama;
  double hargaModal;
  double hargaJual;
  int stok;
  int terjual;
  String? imageBase64;

  Produk({
    required this.id,
    required this.nama,
    required this.hargaModal,
    required this.hargaJual,
    required this.stok,
    this.terjual = 0,
    this.imageBase64,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'nama': nama,
        'hargaModal': hargaModal,
        'hargaJual': hargaJual,
        'stok': stok,
        'terjual': terjual,
        'imageBase64': imageBase64,
      };

  factory Produk.fromJson(Map<String, dynamic> json) => Produk(
        id: json['id'],
        nama: json['nama'],
        hargaModal: (json['hargaModal'] as num).toDouble(),
        hargaJual: (json['hargaJual'] as num).toDouble(),
        stok: json['stok'],
        terjual: json['terjual'] ?? 0,
        imageBase64: json['imageBase64'],
      );
}

// --- HALAMAN UTAMA ---
class MainNavigation extends StatefulWidget {
  const MainNavigation({super.key});

  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _selectedIndex = 0;
  double totalTabungan = 0;
  double targetTabungan = 5000000;
  List<Transaksi> daftarTransaksi = [];
  List<Produk> daftarProduk = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  // Muat data tersimpan dari memori perangkat/browser
  Future<void> _loadData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      totalTabungan = prefs.getDouble('totalTabungan') ?? 0;
      targetTabungan = prefs.getDouble('targetTabungan') ?? 5000000;

      final trxString = prefs.getString('daftarTransaksi');
      if (trxString != null) {
        final List decoded = jsonDecode(trxString);
        daftarTransaksi = decoded.map((e) => Transaksi.fromJson(e)).toList();
      }

      final prodString = prefs.getString('daftarProduk');
      if (prodString != null) {
        final List decoded = jsonDecode(prodString);
        daftarProduk = decoded.map((e) => Produk.fromJson(e)).toList();
      } else {
        // Contoh produk awal jika masih kosong
        daftarProduk = [
          Produk(id: '1', nama: 'Kopi Susu Gula Aren', hargaModal: 8000, hargaJual: 18000, stok: 20),
          Produk(id: '2', nama: 'Roti Bakar Coklat Keju', hargaModal: 7000, hargaJual: 15000, stok: 12),
        ];
      }
      isLoading = false;
    });
  }

  // Simpan otomatis setiap ada perubahan
  Future<void> _saveData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('totalTabungan', totalTabungan);
    await prefs.setDouble('targetTabungan', targetTabungan);
    await prefs.setString('daftarTransaksi', jsonEncode(daftarTransaksi.map((e) => e.toJson()).toList()));
    await prefs.setString('daftarProduk', jsonEncode(daftarProduk.map((e) => e.toJson()).toList()));
  }

  double get totalPemasukan => daftarTransaksi
      .where((t) => t.isPemasukan)
      .fold(0, (sum, item) => sum + item.nominal);

  double get totalPengeluaran => daftarTransaksi
      .where((t) => !t.isPemasukan)
      .fold(0, (sum, item) => sum + item.nominal);

  double get totalKeuntunganBersih => daftarTransaksi
      .where((t) => t.isPemasukan)
      .fold(0, (sum, item) => sum + (item.nominal - item.modal));

  double get saldoAktif => totalPemasukan - totalPengeluaran - totalTabungan;

  void _produkTerjual(int index) {
    final produk = daftarProduk[index];
    if (produk.stok <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Stok ${produk.nama} habis! Tambah stok dulu.'),
          backgroundColor: Colors.red.shade700,
        ),
      );
      return;
    }

    final trxBaru = Transaksi(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      judul: 'Terjual: ${produk.nama}',
      nominal: produk.hargaJual,
      modal: produk.hargaModal,
      isPemasukan: true,
      tanggal: DateTime.now(),
    );

    setState(() {
      produk.stok -= 1;
      produk.terjual += 1;
      daftarTransaksi.insert(0, trxBaru);
    });
    _saveData();

    // Tampilkan struk ringkas otomatis
    _tampilkanStruk(produk, trxBaru);
  }

  void _tampilkanStruk(Produk produk, Transaksi trx) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.check_circle, color: Color(0xFF006D5B), size: 56),
            const SizedBox(height: 8),
            const Text('Transaksi Berhasil!', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            Text(DateFormat('dd MMM yyyy, HH:mm').format(trx.tanggal), style: const TextStyle(color: Colors.grey)),
            const Divider(height: 28),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(produk.nama, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                Text(formatRupiah(produk.hargaJual), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Sisa Stok Produk', style: TextStyle(color: Colors.grey)),
                Text('${produk.stok} pcs', style: const TextStyle(fontWeight: FontWeight.bold)),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Profit Transaksi Ini', style: TextStyle(color: Colors.grey)),
                Text('+${formatRupiah(produk.hargaJual - produk.hargaModal)}',
                    style: const TextStyle(color: Colors.teal, fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Selesai'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _tambahTransaksi(String judul, double nominal, bool isMasuk) {
    setState(() {
      daftarTransaksi.insert(
        0,
        Transaksi(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          judul: judul,
          nominal: nominal,
          isPemasukan: isMasuk,
          tanggal: DateTime.now(),
        ),
      );
    });
    _saveData();
  }

  void _tambahTabungan(double nominal) {
    setState(() {
      totalTabungan += nominal;
    });
    _saveData();
  }

  void _ubahTargetTabungan(double targetBaru) {
    setState(() {
      targetTabungan = targetBaru;
    });
    _saveData();
  }

  void _tambahProdukBaru(Produk produk) {
    setState(() {
      daftarProduk.add(produk);
    });
    _saveData();
  }

  void _updateStokProduk(int index, int tambahanStok) {
    setState(() {
      daftarProduk[index].stok += tambahanStok;
    });
    _saveData();
  }

  void _hapusProduk(int index) {
    setState(() {
      daftarProduk.removeAt(index);
    });
    _saveData();
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final pages = [
      KatalogProdukPage(
        produkList: daftarProduk,
        onJualProduk: _produkTerjual,
        onTambahProduk: _tambahProdukBaru,
        onTambahStok: _updateStokProduk,
        onHapusProduk: _hapusProduk,
      ),
      DashboardKeuanganPage(
        saldo: saldoAktif,
        pemasukan: totalPemasukan,
        pengeluaran: totalPengeluaran,
        profit: totalKeuntunganBersih,
        tabungan: totalTabungan,
        targetTabungan: targetTabungan,
        transaksi: daftarTransaksi,
        onTambahTransaksi: _tambahTransaksi,
        onTambahTabungan: _tambahTabungan,
        onUbahTarget: _ubahTargetTabungan,
      ),
    ];

    return Scaffold(
      body: pages[_selectedIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: (index) => setState(() => _selectedIndex = index),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.storefront_outlined),
            selectedIcon: Icon(Icons.storefront),
            label: 'Produk & Kasir',
          ),
          NavigationDestination(
            icon: Icon(Icons.account_balance_wallet_outlined),
            selectedIcon: Icon(Icons.account_balance_wallet),
            label: 'Keuangan & Tabungan',
          ),
        ],
      ),
    );
  }
}

// --- HALAMAN 1: KATALOG PRODUK & ONE-TAP SELL ---
class KatalogProdukPage extends StatelessWidget {
  final List<Produk> produkList;
  final Function(int) onJualProduk;
  final Function(Produk) onTambahProduk;
  final Function(int, int) onTambahStok;
  final Function(int) onHapusProduk;

  const KatalogProdukPage({
    super.key,
    required this.produkList,
    required this.onJualProduk,
    required this.onTambahProduk,
    required this.onTambahStok,
    required this.onHapusProduk,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Katalog Produk', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: Chip(
              avatar: const Icon(Icons.touch_app, size: 16),
              label: const Text('Tap = Terjual', style: TextStyle(fontSize: 12)),
            ),
          )
        ],
      ),
      body: produkList.isEmpty
          ? const Center(child: Text('Belum ada produk. Tekan tombol + Produk Baru.'))
          : GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 0.72,
                crossAxisSpacing: 14,
                mainAxisSpacing: 14,
              ),
              itemCount: produkList.length,
              itemBuilder: (context, index) {
                final item = produkList[index];
                final habis = item.stok <= 0;
                return Card(
                  elevation: 2,
                  clipBehavior: Clip.antiAlias,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                  child: InkWell(
                    onTap: () => onJualProduk(index),
                    onLongPress: () => _menuOpsiProduk(context, index, item),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Stack(
                            fit: StackFit.expand,
                            children: [
                              item.imageBase64 != null
                                  ? Image.memory(base64Decode(item.imageBase64!), fit: BoxFit.cover)
                                  : Container(
                                      color: Colors.teal.shade50,
                                      child: Icon(Icons.inventory_2_rounded, size: 52, color: Colors.teal.shade300),
                                    ),
                              Positioned(
                                top: 8,
                                right: 8,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: habis ? Colors.red : Colors.black87,
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Text(
                                    habis ? 'HABIS' : 'Stok: ${item.stok}',
                                    style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold),
                                  ),
                                ),
                              ),
                              if (item.terjual > 0)
                                Positioned(
                                  bottom: 8,
                                  left: 8,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                    decoration: BoxDecoration(
                                      color: Colors.teal.shade700,
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Text(
                                      'Terjual ${item.terjual}x',
                                      style: const TextStyle(color: Colors.white, fontSize: 10),
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                item.nama,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                formatRupiah(item.hargaJual),
                                style: const TextStyle(color: Color(0xFF006D5B), fontWeight: FontWeight.w800, fontSize: 15),
                              ),
                              const SizedBox(height: 8),
                              Container(
                                width: double.infinity,
                                padding: const EdgeInsets.symmetric(vertical: 6),
                                decoration: BoxDecoration(
                                  color: habis ? Colors.grey.shade300 : const Color(0xFF006D5B),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                alignment: Alignment.center,
                                child: Text(
                                  habis ? 'Stok Kosong' : 'TERJUAL (+1)',
                                  style: TextStyle(
                                    color: habis ? Colors.grey.shade700 : Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _dialogTambahProduk(context),
        icon: const Icon(Icons.add_photo_alternate),
        label: const Text('Produk Baru'),
      ),
    );
  }

  void _menuOpsiProduk(BuildContext context, int index, Produk item) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.add_circle_outline, color: Colors.teal),
              title: Text('Tambah Stok (${item.nama})'),
              onTap: () {
                Navigator.pop(ctx);
                onTambahStok(index, 5);
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline, color: Colors.red),
              title: const Text('Hapus Produk'),
              onTap: () {
                Navigator.pop(ctx);
                onHapusProduk(index);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _dialogTambahProduk(BuildContext context) {
    final namaCtrl = TextEditingController();
    final modalCtrl = TextEditingController();
    final hargaCtrl = TextEditingController();
    final stokCtrl = TextEditingController(text: '10');
    String? base64Image;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('Tambah Produk Baru'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                GestureDetector(
                  onTap: () async {
                    final picker = ImagePicker();
                    final image = await picker.pickImage(source: ImageSource.gallery, maxWidth: 600, imageQuality: 75);
                    if (image != null) {
                      final bytes = await image.readAsBytes();
                      setDialogState(() => base64Image = base64Encode(bytes));
                    }
                  },
                  child: Container(
                    height: 120,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: Colors.teal.shade50,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: Colors.teal.shade200),
                    ),
                    child: base64Image == null
                        ? const Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.add_a_photo, size: 36, color: Colors.teal),
                              SizedBox(height: 6),
                              Text('Upload Gambar Produk', style: TextStyle(color: Colors.teal)),
                            ],
                          )
                        : ClipRRect(
                            borderRadius: BorderRadius.circular(14),
                            child: Image.memory(base64Decode(base64Image!), fit: BoxFit.cover),
                          ),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(controller: namaCtrl, decoration: const InputDecoration(labelText: 'Nama Produk', border: OutlineInputBorder())),
                const SizedBox(height: 10),
                TextField(
                  controller: modalCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Harga Modal (Rp)', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: hargaCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Harga Jual (Rp)', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: stokCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Stok Awal', border: OutlineInputBorder()),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Batal')),
            FilledButton(
              onPressed: () {
                if (namaCtrl.text.isNotEmpty && hargaCtrl.text.isNotEmpty) {
                  onTambahProduk(Produk(
                    id: DateTime.now().millisecondsSinceEpoch.toString(),
                    nama: namaCtrl.text,
                    hargaModal: double.tryParse(modalCtrl.text) ?? 0,
                    hargaJual: double.tryParse(hargaCtrl.text) ?? 0,
                    stok: int.tryParse(stokCtrl.text) ?? 1,
                    imageBase64: base64Image,
                  ));
                  Navigator.pop(ctx);
                }
              },
              child: const Text('Simpan Produk'),
            ),
          ],
        ),
      ),
    );
  }
}

// --- HALAMAN 2: KEUANGAN, LABA & TABUNGAN ---
class DashboardKeuanganPage extends StatelessWidget {
  final double saldo;
  final double pemasukan;
  final double pengeluaran;
  final double profit;
  final double tabungan;
  final double targetTabungan;
  final List<Transaksi> transaksi;
  final Function(String, double, bool) onTambahTransaksi;
  final Function(double) onTambahTabungan;
  final Function(double) onUbahTarget;

  const DashboardKeuanganPage({
    super.key,
    required this.saldo,
    required this.pemasukan,
    required this.pengeluaran,
    required this.profit,
    required this.tabungan,
    required this.targetTabungan,
    required this.transaksi,
    required this.onTambahTransaksi,
    required this.onTambahTabungan,
    required this.onUbahTarget,
  });

  @override
  Widget build(BuildContext context) {
    final progressTabungan = (tabungan / (targetTabungan > 0 ? targetTabungan : 1)).clamp(0.0, 1.0);

    return Scaffold(
      appBar: AppBar(title: const Text('Keuangan & Tabungan', style: TextStyle(fontWeight: FontWeight.bold))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF005B4C), Color(0xFF00967D)]),
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Saldo Kas Aktif', style: TextStyle(color: Colors.white70, fontSize: 14)),
                const SizedBox(height: 4),
                Text(formatRupiah(saldo), style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.bold)),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Pemasukan', style: TextStyle(color: Colors.white70, fontSize: 12)),
                          Text(formatRupiah(pemasukan), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Pengeluaran', style: TextStyle(color: Colors.white70, fontSize: 12)),
                          Text(formatRupiah(pengeluaran), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Laba Bersih', style: TextStyle(color: Colors.amberAccent, fontSize: 12)),
                          Text(formatRupiah(profit), style: const TextStyle(color: Colors.amberAccent, fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // Kartu Celengan / Tabungan
          Card(
            elevation: 1,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.savings, color: Colors.amber),
                          SizedBox(width: 8),
                          Text('Celengan Tabungan', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                        ],
                      ),
                      FilledButton.tonal(
                        onPressed: () => _dialogTabungan(context),
                        child: const Text('+ Nabung'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text('${formatRupiah(tabungan)} / ${formatRupiah(targetTabungan)}',
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 8),
                  LinearProgressIndicator(
                    value: progressTabungan,
                    minHeight: 10,
                    borderRadius: BorderRadius.circular(8),
                    color: Colors.amber.shade700,
                    backgroundColor: Colors.amber.shade100,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),

          const Text('Riwayat Arus Kas', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          if (transaksi.isEmpty)
            const Padding(
              padding: EdgeInsets.all(24),
              child: Center(child: Text('Belum ada catatan pemasukan atau pengeluaran.')),
            )
          else
            ...transaksi.map((t) => Card(
                  elevation: 0,
                  color: Colors.grey.shade100,
                  margin: const EdgeInsets.only(bottom: 8),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: t.isPemasukan ? Colors.green.shade100 : Colors.red.shade100,
                      child: Icon(
                        t.isPemasukan ? Icons.arrow_downward : Icons.arrow_upward,
                        color: t.isPemasukan ? Colors.green.shade800 : Colors.red.shade800,
                      ),
                    ),
                    title: Text(t.judul, style: const TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: Text(DateFormat('dd MMM yyyy • HH:mm').format(t.tanggal), style: const TextStyle(fontSize: 12)),
                    trailing: Text(
                      '${t.isPemasukan ? '+' : '-'} ${formatRupiah(t.nominal)}',
                      style: TextStyle(
                        color: t.isPemasukan ? Colors.green.shade800 : Colors.red.shade800,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                )),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _dialogTransaksi(context),
        icon: const Icon(Icons.edit_note),
        label: const Text('Catat Kas'),
      ),
    );
  }

  void _dialogTransaksi(BuildContext context) {
    final judulCtrl = TextEditingController();
    final nominalCtrl = TextEditingController();
    bool isMasuk = true;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('Catat Pemasukan / Pengeluaran'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SegmentedButton<bool>(
                segments: const [
                  ButtonSegment(value: true, label: Text('Pemasukan')),
                  ButtonSegment(value: false, label: Text('Pengeluaran')),
                ],
                selected: {isMasuk},
                onSelectionChanged: (val) => setDialogState(() => isMasuk = val.first),
              ),
              const SizedBox(height: 12),
              TextField(controller: judulCtrl, decoration: const InputDecoration(labelText: 'Keterangan', border: OutlineInputBorder())),
              const SizedBox(height: 10),
              TextField(
                controller: nominalCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Nominal (Rp)', border: OutlineInputBorder()),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Batal')),
            FilledButton(
              onPressed: () {
                if (judulCtrl.text.isNotEmpty && nominalCtrl.text.isNotEmpty) {
                  onTambahTransaksi(judulCtrl.text, double.tryParse(nominalCtrl.text) ?? 0, isMasuk);
                  Navigator.pop(ctx);
                }
              },
              child: const Text('Simpan'),
            ),
          ],
        ),
      ),
    );
  }

  void _dialogTabungan(BuildContext context) {
    final nominalCtrl = TextEditingController();
    final targetCtrl = TextEditingController(text: targetTabungan.toInt().toString());
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Tabungan & Target'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nominalCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Tambah Setoran Tabungan (Rp)', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: targetCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Target Tabungan (Rp)', border: OutlineInputBorder()),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Batal')),
          FilledButton(
            onPressed: () {
              final setor = double.tryParse(nominalCtrl.text) ?? 0;
              final target = double.tryParse(targetCtrl.text) ?? targetTabungan;
              if (setor > 0) onTambahTabungan(setor);
              if (target > 0) onUbahTarget(target);
              Navigator.pop(ctx);
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }
}
