# Kasir & Tabungan Pro (Flutter Native APK + Web)

Aplikasi pencatatan pemasukan, pengeluaran, tabungan (dengan target), serta katalog produk lengkap dengan gambar, stok, laporan laba bersih, struk otomatis, dan fitur **One-Tap Terjual**.

## Cara Menggunakan di GitHub (Otomatis Jadi APK & Web)
1. Buat repositori baru di GitHub.
2. Ekstrak file ZIP ini dan upload semua isinya (termasuk folder `.github`) ke branch `main`.
3. GitHub Actions akan otomatis merakit file `.apk` dan web-nya:
   - **Download APK:** Buka tab **Actions** di GitHub -> klik workflow yang selesai -> unduh di bagian **Artifacts (`kasir-tabungan-pro-apk`)**.
   - **Buka Versi Web:** Masuk ke **Settings -> Pages** -> pilih source **Deploy from a branch** -> pilih branch **`gh-pages`** -> Save.
